# Спасибо от Сбербанка - вёрстка

`npm run start` - для разработки

`npm run build` - для `production` сборки
